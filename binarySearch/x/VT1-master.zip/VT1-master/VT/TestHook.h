#pragma once
#include <ntifs.h>

EXTERN_C NTSTATUS AsmNtOpenProcess();