#pragma once
#include <ntifs.h>

EXTERN_C VOID KiSystemCall64Shadow();