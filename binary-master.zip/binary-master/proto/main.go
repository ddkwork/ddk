package main

/*
#cgo CFLAGS:
#cgo LDFLAGS:
#include <stdlib.h>

typedef struct {
	void *arg;
	void (*log)(void *arg, int type, const char *str);
	void (*addDepth)(void *arg);
	void (*subDepth)(void *arg);
	void (*addItem)(void *arg, int offset, int len, const char *name, const char *info, const char *value);
} Decode;

static inline void DecodeLog(Decode *dec, int type, const char *str) { dec->log(dec->arg, type, str); }
static inline void DecodeAddDepth(Decode *dec) { dec->addDepth(dec->arg); }
static inline void DecodeSubDepth(Decode *dec) { dec->subDepth(dec->arg); }
static inline void DecodeAddItem(Decode *dec, int offset, int len,
		const char *name, const char *info, const char *value) {
	dec->addItem(dec->arg, offset, len, name, info, value);
}
*/
import "C"
import (
	"fmt"
	"sort"
	"time"
	"unsafe"
)

type LogLevel int

const (
	LL_Verbose LogLevel = iota
	LL_Debug
	LL_Info
	LL_Warning
	LL_Error
	LL_Critical
)

type _pos struct {
	start int
	end   int
}

func (pos _pos) isSub(p _pos) bool {
	return pos.start <= p.start && p.end <= pos.end
}

type _item struct {
	_pos
	name  string
	info  string
	value string
}

type _context struct {
	cbk   *C.Decode
	items map[_pos]*_item
}

func newContext(cbk *C.Decode) *_context {
	return &_context{cbk: cbk, items: make(map[_pos]*_item)}
}

func (ctx *_context) decode(buf []byte, a any) {
	defer ctx.output()
	ctx.log(LL_Verbose, "decode start. all length is %d", len(buf))
	dec := NewDecoder(ctx.addItem, buf, 0)
	defer func() {
		r := recover()
		if r == nil {
			return
		}
		pos := dec.Pos()
		info := ""
		switch e := r.(type) {
		case string:
			info = e
		case error:
			info = e.Error()
		default:
			info = fmt.Sprint(e)
		}
		ctx.log(LL_Error, "decode error where pos is %d.%d that %s", pos/8, pos%8, info)
	}()
	dec.Decode(a, nil)
	ctx.log(LL_Info, "decode success. decode length is %d", dec.Pos()/8)
}

func (ctx *_context) addItem(start, end int, name, info, value string) {
	if start >= end {
		return
	}
	item := &_item{_pos: _pos{start, end}, name: name, info: info, value: value}

	if old, ok := ctx.items[item._pos]; ok {
		if len(name) == 0 && len(old.name) != 0 {
			item.name = old.name
		}
		if len(info) == 0 && len(old.info) != 0 {
			item.info = old.info
		}
		if len(value) == 0 && len(old.value) != 0 {
			item.value = old.value
		}
	}

	ctx.items[item._pos] = item
}

func (ctx *_context) outputItem(item *_item) {
	name := C.CString(item.name)
	info := C.CString(item.info)
	value := C.CString(item.value)
	defer C.free(unsafe.Pointer(name))
	defer C.free(unsafe.Pointer(info))
	defer C.free(unsafe.Pointer(value))

	start := C.int(item.start / 8)
	length := C.int((item.end-1)/8 + 1 - item.start/8)
	C.DecodeAddItem(ctx.cbk, start, length, name, info, value)
}

func (ctx *_context) log(ll LogLevel, format string, a ...any) {
	cstr := C.CString(fmt.Sprintf(format, a...))
	defer C.free(unsafe.Pointer(cstr))
	C.DecodeLog(ctx.cbk, C.int(ll), cstr)
}

func (ctx *_context) output() {
	if len(ctx.items) <= 1 {
		return
	}

	ctx.log(LL_Debug, "output item number is %d", len(ctx.items)-1)
	list := make([]*_item, 0, len(ctx.items))
	for _, v := range ctx.items {
		list = append(list, v)
	}
	sort.Slice(list, func(i, j int) bool {
		if list[i].start != list[j].start {
			return list[i].start < list[j].start
		}
		return list[i].end > list[j].end
	})

	list = list[1:] // 丢掉最外层的item
	for len(list) > 0 {
		list = ctx.outputTree(list)
	}
}

func (ctx *_context) outputTree(list []*_item) []*_item {
	root := list[0]
	ctx.outputItem(root)
	if len(list) <= 1 {
		return nil
	} else if !root.isSub(list[1]._pos) {
		return list[1:]
	}

	C.DecodeAddDepth(ctx.cbk)
	defer C.DecodeSubDepth(ctx.cbk)

	list = list[1:]
	for len(list) > 0 {
		if !root.isSub(list[0]._pos) {
			break
		}
		list = ctx.outputTree(list)
	}
	return list
}

//export DecodeStream
func DecodeStream(dec *C.Decode, buf unsafe.Pointer, bufLen C.int) {
	goBuf := (*[0x7FFFFFFF]byte)(buf)[:bufLen:bufLen]
	var st Root
	newContext(dec).decode(goBuf, &st)
}

//export SupportFileFilter
func SupportFileFilter() string {
	return fileFilter
}

func main() {}

func fieldString(fieldMap []string, v uint64, size int) string {
	str := ""
	for i := 0; i < size; i++ {
		mask := uint64(1 << i)
		if v&mask == 0 {
			continue
		}
		if i >= len(fieldMap) || len(fieldMap[i]) == 0 {
			continue
		}
		v &= ^mask
		str += "|" + fieldMap[i]
	}
	if v != 0 {
		str += fmt.Sprintf("|%#X", v)
	}
	if len(str) <= 0 {
		return "0"
	}
	return str[1:]
}

type TimeStamp uint32

func (t TimeStamp) String() string {
	if t == 0 {
		return "invalid"
	}
	return time.Unix(int64(t), 0).String()
}

type WString string

func (s *WString) Unmarshal(dec *Decoder, info *ValueInfo) {
	pos := dec.Pos()

	bs := dec.ReadBytes(0)
	var cs []rune
	for i := 0; i < len(bs)-1; i += 2 {
		c := rune(0)
		if info.isBig {
			c = (rune(bs[i]) << 8) + rune(bs[i+1])
		} else {
			c = rune(bs[i]) + (rune(bs[i+1]) << 8)
		}
		if c == 0 {
			break
		}
		cs = append(cs, c)
	}
	*s = WString(cs)

	pos += len(cs) * 16
	if len(cs)*2 < len(bs)-1 {
		pos += 16
	}
	dec.Seek(pos)
}
