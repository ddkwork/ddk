# go-gitignore

[![Build Status](https://travis-ci.org/sabhiram/go-gitignore.svg)](https://travis-ci.org/sabhiram/go-gitignore) [![Coverage Status](https://coveralls.io/repos/github/sabhiram/go-gitignore/badge.svg?branch=master)](https://coveralls.io/github/sabhiram/go-gitignore?branch=master)

A gitignore parser for `Go`

## Install

```shell
go get github.com/sabhiram/go-gitignore
```

## Usage

For a quick sample of how to use this library, check out the tests under `ignore_test.go`.
