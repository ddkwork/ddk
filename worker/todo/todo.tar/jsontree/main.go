package jsontree

import (
	_ "embed"
	"github.com/ddkwork/encoding/jsontree"
	"github.com/ddkwork/ux"
)

//go:embed product-info.json
var productInfo []byte

func New() ux.Widget {
	return jsontree.Layout(productInfo)
}
