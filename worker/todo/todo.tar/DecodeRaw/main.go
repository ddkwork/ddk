package DecodeRaw

import (
	"github.com/ddkwork/encoding/myProtobuf/goprotoc"
	"github.com/ddkwork/encoding/myProtobuf/test/session"
	"github.com/ddkwork/ux"
	"os"
)

func New() ux.Widget {
	return goprotoc.DecodeRaw(session.GooglePb(), os.Stdout)
}
