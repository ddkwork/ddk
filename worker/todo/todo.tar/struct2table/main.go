package struct2table

import (
	"github.com/ddkwork/encoding/myProtobuf/test/session"
	"github.com/ddkwork/encoding/struct2table"
	"github.com/ddkwork/ux"
)

func New() ux.Widget {
	return struct2table.Marshal(session.Message)
}
